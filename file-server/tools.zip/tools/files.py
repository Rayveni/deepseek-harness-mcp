"""Инструменты для работы с файлами: чтение, запись, удаление, поиск.

Все пути интерпретируются относительно FILES_ROOT (по умолчанию /workspace)
и не могут выйти за его пределы — выход за корень запрещён.
"""

import os
import re
import shutil
from pathlib import Path

# Корневая папка, с которой разрешено работать. Задаётся через env.
FILES_ROOT = Path(os.environ.get("FILES_ROOT", "/workspace")).resolve()


def _resolve(path: str) -> Path:
    """Разрешает относительный путь относительно FILES_ROOT и проверяет,
    что результат остаётся внутри корневой папки."""
    target = Path(path)
    if not target.is_absolute():
        target = FILES_ROOT / target
    target = target.resolve()
    if FILES_ROOT != target and FILES_ROOT not in target.parents:
        raise ValueError(f"Доступ запрещён: путь '{path}' выходит за пределы {FILES_ROOT}")
    return target


def register(mcp) -> None:
    @mcp.tool(output_schema=None)
    def read_file(path: str, offset: int = 1, limit: int = 2000) -> str:
        """Читает текстовый файл. offset — номер первой строки (с 1),
        limit — максимальное число строк."""
        target = _resolve(path)
        if not target.is_file():
            raise FileNotFoundError(f"Файл не найден: {path}")
        lines = target.read_text(encoding="utf-8").splitlines()
        total = len(lines)
        chunk = lines[offset - 1 : offset - 1 + limit]
        return "\n".join(chunk) + f"\n--- (строки {offset}-{offset - 1 + len(chunk)} из {total}) ---"

    @mcp.tool(output_schema=None)
    def write_file(path: str, content: str) -> str:
        """Создаёт или перезаписывает текстовый файл.
        Недостающие родительские директории создаются автоматически."""
        target = _resolve(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return f"Записано {len(content)} символов в {path}"

    @mcp.tool(output_schema=None)
    def delete_file(path: str) -> str:
        """Удаляет файл. Пустая родительская директория не удаляется."""
        target = _resolve(path)
        if not target.is_file():
            raise FileNotFoundError(f"Файл не найден: {path}")
        target.unlink()
        return f"Удалён файл: {path}"

    @mcp.tool(output_schema=None)
    def create_directory(path: str) -> str:
        """Создаёт директорию (и родительские, если нужно)."""
        target = _resolve(path)
        target.mkdir(parents=True, exist_ok=True)
        return f"Директория готова: {path}"

    @mcp.tool(output_schema=None)
    def list_directory(path: str = ".") -> str:
        """Выводит содержимое директории: файлы, поддиректории и размеры."""
        target = _resolve(path)
        if not target.is_dir():
            raise NotADirectoryError(f"Не директория: {path}")
        entries = sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        if not entries:
            return f"(пусто) {path}"
        return "\n".join(
            f"{'[DIR] ' if p.is_dir() else '      '}{p.name}"
            + (f"  ({p.stat().st_size} байт)" if p.is_file() else "")
            for p in entries
        )

    @mcp.tool(output_schema=None)
    def search_files(pattern: str, path: str = ".", include: str = "*") -> str:
        """Ищет regex-совпадения в файлах директории (рекурсивно).
        include — glob-маска для файлов, например '*.py'."""
        import fnmatch

        root = _resolve(path)
        if not root.is_dir():
            raise NotADirectoryError(f"Не директория: {path}")
        regex = re.compile(pattern)
        results = []
        for file_path in sorted(root.rglob("*")):
            if not file_path.is_file() or not fnmatch.fnmatch(file_path.name, include):
                continue
            try:
                lines = file_path.read_text(encoding="utf-8").splitlines()
            except (UnicodeDecodeError, PermissionError):
                continue
            for i, line in enumerate(lines, start=1):
                if regex.search(line):
                    results.append(f"{file_path.relative_to(FILES_ROOT)}:{i}:{line.strip()}")
        if not results:
            return f"Совпадений не найдено: /{pattern}/ в {path}"
        return "\n".join(results[:250]) + (f"\n--- (показано 250 из {len(results)}) ---" if len(results) > 250 else "")

    @mcp.tool(output_schema=None)
    def file_info(path: str) -> str:
        """Возвращает метаданные файла или директории: тип, размер, время правок."""
        import datetime

        target = _resolve(path)
        if not target.exists():
            raise FileNotFoundError(f"Не найдено: {path}")
        stat = target.stat()
        kind = "директория" if target.is_dir() else "файл"
        modified = datetime.datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")
        return f"{kind}: {path}\nразмер: {stat.st_size} байт\nизменён: {modified}"

    @mcp.tool(output_schema=None)
    def move_file(source: str, destination: str) -> str:
        """Перемещает или переименовывает файл/директорию внутри корня."""
        src = _resolve(source)
        dst = _resolve(destination)
        if not src.exists():
            raise FileNotFoundError(f"Источник не найден: {source}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        return f"Перемещено: {source} -> {destination}"
